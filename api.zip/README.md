# Instructions

Run
- npm i
- add .env (MONGO_URL=mongodb://localhost:27017/test-feb28)
- npm run start