/**
 * catchAsync function takes a function as an argument and then
 * executes it. In case of any error, the request is passed to
 * error handler.
 * 
 * @param   {function():void}   fn
 * @returns {function(Object, Object, Object)}
*/

module.exports = fn => (req, res, next) => {
	fn(req, res, next).catch(next)
}