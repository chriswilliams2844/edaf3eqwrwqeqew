# Utils

Utils folder contains miscellaneous functions which are used in different files.