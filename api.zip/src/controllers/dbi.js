/**
 * Database integration file
 * Responsible for performing CRUD operation
 * with MongoDB
*/

const catchAsync = require('../utils/catchAsync');

/**
 * getAll function takes any model and returns a function
 * which returns all documents of that model.
 * 
 * @param   { Object }  Model   -Model to fetch data
 * 
 * @returns { function(Object, Object, Object): Object }
*/

exports.getAll = Model =>
	catchAsync(async (req, res, next) => {
		const docs = await Model.find({});
		res.status(200).json({
			status: 'success',
			total: docs.length,
			data: docs,
		})
	});

/**
 * createOne function takes any model and returns a function
 * which adds a document to that collection corresponding to model.
 * After inserting the document, the function returns the recently
 * added document.
 * 
 * @param   { Object }  Model   -Model to fetch data
 * 
 * @returns { function(Object, Object, Object): Object }
*/

exports.createOne = Model =>
	catchAsync(async (req, res, next) => {
		const doc = await Model.create(req.body)
		res.status(200).json({
			status: 'success',
			data: doc,
		})
	})

exports.updateOne = Model =>
	catchAsync(async (req, res, next) => {
		const doc = await Model.findByIdAndUpdate(req.params.id, req.body, {
			new: true,
			runValidators: true,
			upsert: true
		});
		res.status(200).json({
			status: 'success',
			data: doc,
		});
	});

exports.deleteOne = Model =>
	catchAsync(async (req, res, next) => {
		const doc = await Model.findByIdAndDelete(req.params.id);
		res.status(200).json({
			status: 'success',
			data: doc,
		})
	});