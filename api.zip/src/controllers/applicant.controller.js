const Applicant = require("../models/applicant");
const dbi = require("./dbi");
const catchAsync = require("../utils/catchAsync");

exports.getAll = dbi.getAll(Applicant);
exports.createOne = dbi.createOne(Applicant);
exports.updateOne = dbi.updateOne(Applicant);
exports.deleteOne = dbi.deleteOne(Applicant);

exports.search = catchAsync(async (req, res) => {

    const regex = new RegExp(req.query.q, "i");
    const results = await Applicant.find({
        $or: [
            {firstName: regex},
            {lastName: regex},
            {phoneNumber: regex}
        ]
    });

    res.send({
        status: "success",
        data: results,
    });

});