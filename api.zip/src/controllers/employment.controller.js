const Employment = require("../models/employment");
const dbi = require("./dbi");

exports.getAll = dbi.getAll(Employment);
exports.createOne = dbi.createOne(Employment);
exports.updateOne = dbi.updateOne(Employment);
exports.deleteOne = dbi.deleteOne(Employment);