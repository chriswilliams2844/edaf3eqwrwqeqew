const Education = require("../models/education");
const dbi = require("./dbi");

exports.getAll = dbi.getAll(Education);
exports.createOne = dbi.createOne(Education);
exports.updateOne = dbi.updateOne(Education);
exports.deleteOne = dbi.deleteOne(Education);