const express = require("express");
const mongoose = require("mongoose");
const morgan = require("morgan");
const router = require("./routes/root.routes");

const app = express();  //Create new instance
require("dotenv").config();

mongoose
  //.connect('mongodb://localhost:27017')
  .connect(process.env.MONGO_URL)   // read environment varibale from .env
  .then(() => {
    console.log("Database connection Success!");
  })
  .catch((err) => {
    console.error("Mongo Connection Error", err);
  });
const PORT = process.env.PORT || 3000; //Declare the port number
app.use(express.json()); //allows us to access request body as req.body
app.use(morgan("dev"));  //enable incoming request logging in dev mode

//add routes
app.use(router);

//read people from db

app.get('/activity',(req, res, next)=>{
  activityModel.find(
    (error, data) => {
      if (error) {
      return next(error)
      }
      else{
      res.json(data)
      }
    })
});

app.listen(PORT, () => {
    console.log("Server started listening on port : ", PORT);
  });
  // error handler
  app.use(function (err, req, res, next) {
      console.error(err.message);
      if (!err.statusCode) 
          err.statusCode = 500;
      res.status(err.statusCode).send(err.message);
  });