const router = require("express").Router();
const employmentController = require("../controllers/employment.controller");

router.get("/", employmentController.getAll);
router.post("/", employmentController.createOne);
router.put("/:id", employmentController.updateOne);
router.delete("/:id", employmentController.deleteOne);

module.exports = router;