const router = require("express").Router();

const applicantRouter = require("./applicant.router");
const educationRouter = require("./education.router");
const employmentRouter = require("./employment.router");

router.use("/applicant", applicantRouter);
router.use("/education", educationRouter);
router.use("/employment", employmentRouter);

module.exports = router;