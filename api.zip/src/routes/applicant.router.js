const router = require("express").Router();
const controller = require("../controllers/applicant.controller");

router.get("/", controller.getAll);
router.post("/", controller.createOne);
router.put("/:id", controller.updateOne);
router.delete("/:id", controller.deleteOne);
router.get("/search", controller.search);

module.exports = router;