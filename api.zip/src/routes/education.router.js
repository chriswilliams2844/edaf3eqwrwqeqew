const router = require("express").Router();
const educationController = require("../controllers/education.controller");

router.get("/", educationController.getAll);
router.post("/", educationController.createOne);
router.put("/:id", educationController.updateOne);
router.delete("/:id", educationController.deleteOne);

module.exports = router;