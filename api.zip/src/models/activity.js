const uuid = require('uuid');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let activitySchema = new Schema({
    _id: {
        type: String,
        default: uuid.v1
    },
    clientID: {
        type: Number,
        required: true
    },
    program: {
        type: String,
        required: true
    },
    datetime: {
        type: String,
        required: true
    },
    timeSpend: {
        type: Number,
        required: true
    },
    workerID: {
        type: Number,
        required: true
    },
    hasUsedServices: {
        type: Boolean,
    },
    handlingStatus: {
        type: String,
    },
    eventDescription: {
        type:String,
        required: true
    },
    eventDate: {
        type: String,
        required:true
    },
    eventAddress: {
        type: String,
        required: true
    },
    eventZip: {
        type: String,
        required: true
    },
    },
    {
        //collection: 'activities'
        collection: 'activity'
    });
    
module.exports = mongoose.model('activity', activitySchema)
