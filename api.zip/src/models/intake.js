const uuid = require('uuid');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let intakeSchema = new Schema({
    _id: {
        type: String,
        default: uuid.v1
    },
    clientID: {
        type: Number,
        required: true,
        unique: true
    },
    familyID: {
        type: Number,
        required: true,
        unique: true
    },
    startDate: {
        type: String,
        required: true
    },
    endDate: {
        type: String,
        required: true
    },
    modifyAt: {
        type: Date,
        required: true
    }
},
    {
        collection: 'intakes'
    });

module.exports = mongoose.model('intake', intakeSchema);