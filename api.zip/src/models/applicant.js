//https://mongoosejs.com/docs/populate.html
//11/6/21 Changed boolean to string because axios cant send boolean as the body of a request.
const uuid = require('uuid');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//collection for applicants
let applicantSchema = new Schema({
    //_id: Number,
    // mongoose will assign id itself
    //_id: { type: String, default: uuid.v1 
    //},
    clientID: {
        type: Number
    },
    firstName: {
      type: String
    },
    lastName: {
        type: String
    },
    birthday: {
        type: String
    },
    ssn: {
        type: String
    },
    gender: {
        type: String
    },
    driverLicense: {
        type: Number
    },
    phoneNumber: {
        type: String
      },
    personalEmail: {
        type: String
    },
    maritalStatus: {
        type: String
    },
    language: {
      type: String
    },
    ethnicity: {
        type: String
    },
    isPregnancy: {
        type: Boolean,
        required: true
    },
    isTeenParent: {
        type: Boolean,
        required: true
    },
    deliveryMonth: {
        type: Number
    },
    modifyAt: {
        type: Date
    },
    isNeedSupport: {
      type: String
    },
    isVaccinated: {
      type: String,
    },
    events: 
      [{type: String, ref: 'Event'}]
    
}, {
    collection: 'applicant'
});


//create models for mongoose schema to use applicant and eventList data model ('js', schema name)
const applicant = mongoose.model('Applicant', applicantSchema); 

// package the models in an object to export both
module.exports = applicant;



